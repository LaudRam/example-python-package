# myfirstpackage
This library was created as an example of how to create and publish your own Python package.

## Building this package locally:
`python setup.py sdist`

## Installing from Github:
`pip install git+https://github.com/LaudRam/example-python-package.git`

## Updating package from Github:
`pip install --upgrade git+https://github.com/LaudRam/example-python-package.git`